
import os
import cv2
import numpy as np
import torch
from torch.utils.data import Dataset
import albumentations as A

class RootDataset(Dataset):
    def __init__(self, images_dir, masks_dir, file_list, img_size=768, train=True):
        self.images_dir = images_dir
        self.masks_dir  = masks_dir
        self.file_list  = file_list
        self.img_size   = img_size
        self.train      = train

        if train:
            self.transforms = A.Compose([
                A.Resize(img_size, img_size),
                A.HorizontalFlip(p=0.5),
                A.VerticalFlip(p=0.3),
                A.Rotate(limit=20, border_mode=cv2.BORDER_CONSTANT, p=0.5),
                A.RandomBrightnessContrast(brightness_limit=0.3, contrast_limit=0.3, p=0.5),
                A.GaussianBlur(blur_limit=(3,5), p=0.2),
                A.RandomGamma(gamma_limit=(80,120), p=0.3),
            ], is_check_shapes=False)
        else:
            self.transforms = A.Compose([
                A.Resize(img_size, img_size),
            ], is_check_shapes=False)

    def __len__(self): return len(self.file_list)

    def __getitem__(self, idx):
        fname = self.file_list[idx]

        image = cv2.imread(os.path.join(self.images_dir, fname))
        if image is None:
            raise FileNotFoundError(f"Image not found: {fname}")
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

        mask = cv2.imread(os.path.join(self.masks_dir, fname), cv2.IMREAD_GRAYSCALE)
        if mask is None:
            raise FileNotFoundError(f"Mask not found: {fname}")

        img_h, img_w = image.shape[:2]
        msk_h, msk_w = mask.shape[:2]

        # Fix rotated masks
        if img_h == msk_w and img_w == msk_h and img_h != msk_h:
            mask = cv2.rotate(mask, cv2.ROTATE_90_CLOCKWISE)
            msk_h, msk_w = mask.shape[:2]

        if msk_h != img_h or msk_w != img_w:
            mask = cv2.resize(mask, (img_w, img_h), interpolation=cv2.INTER_NEAREST)

        
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (9, 9))
        mask   = cv2.dilate(mask, kernel, iterations=1)
        # ──────────────────────────────────────────────────────────────────

        mask = (mask > 127).astype(np.float32)

        aug   = self.transforms(image=image, mask=mask)
        image = aug["image"].astype(np.float32) / 255.0
        image = np.transpose(image, (2, 0, 1))
        mask  = np.expand_dims(aug["mask"], axis=0)

        return torch.tensor(image), torch.tensor(mask)
