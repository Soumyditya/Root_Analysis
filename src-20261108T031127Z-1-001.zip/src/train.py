
import os
import sys
sys.path.insert(0, "/content/root_project/src")

import torch
from sklearn.model_selection import train_test_split
from torch.utils.data import DataLoader

from dataset import RootDataset
from model import create_model
from loss import RootLoss


def train(
    images_dir      = "/content/root_project/data/images",
    masks_dir       = "/content/root_project/data/masks",
    checkpoint_path = "/content/root_project/checkpoints/best_model.pth",
    resume          = False,
    epochs          = 100,
    batch_size      = 2,
    lr              = 5e-5,
    img_size        = 768,
    threshold       = 0.5,
    patience        = 20,
):
    os.makedirs(os.path.dirname(checkpoint_path), exist_ok=True)

    files = sorted([
        f for f in os.listdir(images_dir)
        if f.lower().endswith((".png",".jpg",".jpeg"))
        and os.path.exists(os.path.join(masks_dir, f))
    ])
    print(f"Found {len(files)} pairs")
    if len(files) == 0:
        raise RuntimeError("No matched image/mask pairs found.")

    train_files, val_files = train_test_split(files, test_size=0.15, random_state=42)
    print(f"Train: {len(train_files)} | Val: {len(val_files)}")

    train_ds = RootDataset(images_dir, masks_dir, train_files, img_size=img_size, train=True)
    val_ds   = RootDataset(images_dir, masks_dir, val_files,   img_size=img_size, train=False)

    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True,
                               num_workers=2, pin_memory=True)
    val_loader   = DataLoader(val_ds,   batch_size=batch_size, shuffle=False,
                               num_workers=2, pin_memory=True)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Device: {device}")

    model = create_model().to(device)

    if resume and os.path.exists(checkpoint_path):
        model.load_state_dict(torch.load(checkpoint_path, map_location=device))
        print(f"Resumed from: {checkpoint_path}")

    criterion = RootLoss()
    optimizer = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-5)

    def lr_lambda(ep):
        if ep < 10:
            return ep / 10
        return max(0.05, 0.5 * (1 + torch.cos(torch.tensor((ep - 10) / max(1, (epochs - 10)) * 3.14159)).item()))

    scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda)
    scaler    = torch.cuda.amp.GradScaler()

    best_dice, no_improve = 0.0, 0

    for epoch in range(1, epochs + 1):
        model.train()
        train_loss = 0.0
        for imgs, masks in train_loader:
            imgs, masks = imgs.to(device), masks.to(device)
            optimizer.zero_grad()
            with torch.autocast(device_type="cuda"):
                logits = model(imgs)
                loss   = criterion(logits, masks)
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 2.0)
            scaler.step(optimizer)
            scaler.update()
            train_loss += loss.item()
        train_loss /= len(train_loader)

        model.eval()
        val_loss, val_dice, val_recall = 0.0, 0.0, 0.0
        with torch.no_grad():
            for imgs, masks in val_loader:
                imgs, masks = imgs.to(device), masks.to(device)
                with torch.autocast(device_type="cuda"):
                    logits = model(imgs)
                    loss   = criterion(logits, masks)
                val_loss += loss.item()

                # IMPORTANT: same threshold value used here as in predict.py
                preds = (torch.sigmoid(logits) > threshold).float()
                inter = (preds * masks).sum()
                dice  = (2*inter) / (preds.sum() + masks.sum() + 1e-6)
                val_dice += dice.item()
                recall = inter / (masks.sum() + 1e-6)
                val_recall += recall.item()

        val_loss   /= len(val_loader)
        val_dice   /= len(val_loader)
        val_recall /= len(val_loader)
        scheduler.step()

        lr_now = optimizer.param_groups[0]["lr"]
        print(f"Epoch {epoch:03d} | Train {train_loss:.4f} | Val {val_loss:.4f} | "
              f"Dice {val_dice:.4f} | Recall {val_recall:.4f} | LR {lr_now:.2e}")

        if epoch > 15 and val_dice < 0.05:
            print("  [WARN] Dice still near 0 after 15 epochs - check data alignment")

        if val_dice > best_dice:
            best_dice, no_improve = val_dice, 0
            torch.save(model.state_dict(), checkpoint_path)
            print(f"  -> saved (dice={val_dice:.4f}  recall={val_recall:.4f})")
        else:
            no_improve += 1
            if no_improve >= patience:
                print(f"Early stopping at epoch {epoch}")
                break

    print(f"Done. Best Dice: {best_dice:.4f}")
    print(f"Saved: {checkpoint_path}")
