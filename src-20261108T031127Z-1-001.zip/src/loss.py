
import torch
import torch.nn as nn
import segmentation_models_pytorch as smp

class RootLoss(nn.Module):
   
    def __init__(self):
        super().__init__()
        self.dice    = smp.losses.DiceLoss(mode="binary", from_logits=True)
        self.tversky = smp.losses.TverskyLoss(
            mode="binary",
            from_logits=True,
            alpha=0.1,
            beta=0.9,
        )

    def forward(self, logits, targets):
        pos = targets.sum()
        neg = targets.numel() - pos
        if pos > 0:
            pw = torch.clamp(neg / pos, min=10.0, max=2000.0)
        else:
            pw = torch.tensor(1000.0, device=logits.device)

        bce = nn.BCEWithLogitsLoss(pos_weight=pw.to(logits.device))(logits, targets)

        return 0.3 * bce + 0.4 * self.dice(logits, targets) + 0.3 * self.tversky(logits, targets)
