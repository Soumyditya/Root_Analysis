
import os
import sys
sys.path.insert(0, "/content/root_project/src")

import cv2
import torch
import numpy as np
import pandas as pd
import networkx as nx
from skimage.morphology import skeletonize, remove_small_objects
from skimage.measure import label, regionprops

from model import create_model


TEST_DIR    = "/content/root_project/data/test_images"
CHECKPOINT  = "/content/root_project/checkpoints/best_model.pth"   # NOTE: no space before .pth
OUT_MASKS   = "/content/root_project/outputs/masks"
OUT_SKEL    = "/content/root_project/outputs/skeletons"
OUT_CSV     = "/content/root_project/outputs/results/results.csv"
IMG_SIZE    = 768
THRESHOLD   = 0.5
KNOWN_MM_PER_PX = 0.1   # set to your calibration (0.1 = 254 DPI)

for d in [OUT_MASKS, OUT_SKEL, os.path.dirname(OUT_CSV)]:
    os.makedirs(d, exist_ok=True)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Device:", device)

if not os.path.exists(CHECKPOINT):
    raise FileNotFoundError(
        f"Checkpoint not found at {CHECKPOINT}. "
        f"Did training finish and save a model? Check the path."
    )

model = create_model()
model.load_state_dict(torch.load(CHECKPOINT, map_location=device))
model.to(device).eval()
print("Model loaded from:", CHECKPOINT)

def predict_mask(img_rgb, original_hw):
    h, w = original_hw
    x = cv2.resize(img_rgb, (IMG_SIZE, IMG_SIZE)).astype(np.float32) / 255.0
    x = torch.tensor(np.transpose(x,(2,0,1)), dtype=torch.float32).unsqueeze(0).to(device)
    with torch.no_grad():
        pred = torch.sigmoid(model(x)).squeeze().cpu().numpy()
    return cv2.resize(pred, (w, h))

OFFSETS = [(-1,-1),(-1,0),(-1,1),(0,-1),(0,1),(1,-1),(1,0),(1,1)]

def skeleton_to_graph(skel):
    G = nx.Graph()
    ys, xs = np.where(skel)
    coords = set(zip(ys.tolist(), xs.tolist()))
    for (y,x) in coords:
        G.add_node((y,x))
        for dy,dx in OFFSETS:
            nb = (y+dy, x+dx)
            if nb in coords:
                G.add_edge((y,x), nb, weight=float(np.hypot(dy,dx)))
    return G

def calculate_phenotypes(mask):
  
    mask_bool = remove_small_objects(mask > 0, min_size=50)
    if not np.any(mask_bool):
        return 0.0, 0.0

    labels = label(mask_bool)
    props = regionprops(labels)
    largest_comp_label = max(props, key=lambda r: r.area).label
    main_root_mask = (labels == largest_comp_label)

    skel = skeletonize(mask_bool)
    G = skeleton_to_graph(skel)
    trl_px = sum(d["weight"] for _,_,d in G.edges(data=True))

    skel_main = skeletonize(main_root_mask)
    G_main = skeleton_to_graph(skel_main)
    if G_main.number_of_nodes() == 0:
        return trl_px, 0.0

    ys, xs = np.where(skel_main)
    top_y = ys.min()
    crown_nodes = [n for n in G_main.nodes if n[0] <= top_y + 10]
    if not crown_nodes:
        return trl_px, 0.0
    avg_x = np.mean([n[1] for n in crown_nodes])
    source = min(crown_nodes, key=lambda n: abs(n[1] - avg_x))

    lengths = nx.single_source_dijkstra_path_length(G_main, source, weight="weight")
    prl_px = max(lengths.values()) if lengths else 0.0

    return trl_px, prl_px

results = []
for fname in sorted(os.listdir(TEST_DIR)):
    if not fname.lower().endswith((".png",".jpg",".jpeg")):
        continue

    print(f"\nProcessing: {fname}")
    img_bgr = cv2.imread(os.path.join(TEST_DIR, fname))
    img_rgb = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB)
    h, w = img_rgb.shape[:2]

    pred = predict_mask(img_rgb, (h, w))
    print(f"  Prob map: min={pred.min():.3f} max={pred.max():.3f} mean={pred.mean():.4f}")

    mask = (pred > THRESHOLD).astype(np.uint8)
    coverage = mask.sum() / mask.size * 100
    print(f"  Threshold={THRESHOLD}: {mask.sum()} root px ({coverage:.3f}%)")

    trl_px, prl_px = calculate_phenotypes(mask)
    trl_mm = trl_px * KNOWN_MM_PER_PX
    prl_mm = prl_px * KNOWN_MM_PER_PX

    print(f"  TRL = {trl_px:.1f} px = {trl_mm:.2f} mm = {trl_mm/10:.2f} cm")
    print(f"  PRL = {prl_px:.1f} px = {prl_mm:.2f} mm = {prl_mm/10:.2f} cm")

    base = os.path.splitext(fname)[0]
    cv2.imwrite(os.path.join(OUT_MASKS, base + "_mask.png"), mask * 255)

    results.append({
        "image": base,
        "TRL_pixels": round(trl_px, 2),
        "PRL_pixels": round(prl_px, 2),
        "TRL_cm": round(trl_mm/10, 2),
        "PRL_cm": round(prl_mm/10, 2),
        "root_coverage_pct": round(coverage, 4),
    })

df = pd.DataFrame(results)
df.to_csv(OUT_CSV, index=False)
print()
print(df.to_string(index=False))
print(f"\nSaved: {OUT_CSV}")
